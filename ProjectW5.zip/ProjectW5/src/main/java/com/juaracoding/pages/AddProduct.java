package com.juaracoding.pages;

import com.juaracoding.drivers.DriverSingleton;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static org.openqa.selenium.Keys.ENTER;

public class AddProduct {
    private WebDriver driver;

    public AddProduct(){
        this.driver = DriverSingleton.getDriver();
        PageFactory.initElements(driver, this);
    }
    //*[@id="add-to-cart-sauce-labs-backpack"]
    @FindBy(xpath = "//*[@id=\"add-to-cart-sauce-labs-backpack\"]")
    private WebElement addToChart1 ;

    @FindBy(xpath = "//*[@id=\"add-to-cart-sauce-labs-bike-light\"]")
    private WebElement addToChart2 ;

    @FindBy(xpath = "//a[@class='shopping_cart_link']")
    private WebElement shoppingCart;
    @FindBy(xpath = "//*[@id=\"checkout\"]")
    private WebElement checkOutBtn;

    @FindBy(xpath = "//input[@id='first-name']")
    private WebElement checkOutFN;

    @FindBy(xpath = "//input[@id='last-name']")
    private WebElement checkOutLN;

    @FindBy(xpath = "//input[@id='postal-code']")
    private WebElement checkOutZIP;


    @FindBy(xpath = "//*[@id=\"continue\"]")
    private WebElement continueBtn;

    @FindBy(xpath = "//*[@id=\"finish\"]")
    private WebElement finishBtn;


    @FindBy(xpath = "//button[@id='back-to-products']")
    private WebElement backHomeBtn;

    //Validasi
    @FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
    private WebElement validCheckOut;

    @FindBy(xpath = "//h3[@data-test='error']")
    private WebElement invalidCheckOut;

    public void addItem(){
        addToChart1.click();
        addToChart2.click();
    }

    public void checkSC(){
        shoppingCart.click();
    }

    public void checkOut(){
        checkOutBtn.click();
    }

    public void inputData(String fn, String ln, String zip){
        this.checkOutFN.sendKeys(fn);
        this.checkOutLN.sendKeys(ln);
        this.checkOutZIP.sendKeys(zip);
    }

    public void inputFN(String fn){
        this.checkOutFN.sendKeys(fn);
    }

    public void inputLN(String ln){
        this.checkOutLN.sendKeys(ln);
    }

    public void inputZip(String zip){
        this.checkOutZIP.sendKeys(zip);
    }

    public void clearData(){
        checkOutFN.sendKeys(Keys.CONTROL+"a"+Keys.DELETE);
        checkOutLN.sendKeys(Keys.CONTROL+"a"+Keys.DELETE);
        checkOutZIP.sendKeys(Keys.CONTROL+"a"+Keys.DELETE);
    }

    public void continuebtn(){
        continueBtn.click();
    }
    public void finish(){
        finishBtn.click();
    }

    public String validCheckOut(){
        return validCheckOut.getText();
    }

    public void backHome(){
        backHomeBtn.click();
    }

    public String invalidCheckOut(){
        return invalidCheckOut.getText();
    }
}
