package com.juaracoding.pages;

import com.juaracoding.drivers.DriverSingleton;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginLogout {
    private WebDriver driver;

    public LoginLogout(){
        this.driver = DriverSingleton.getDriver();
        PageFactory.initElements(driver, this);
    }

    //Locator use Page Factory
    @FindBy(xpath = "//input[@id='user-name']")
    private WebElement username;

    @FindBy(xpath = "//input[@id='password']")
    private WebElement password;
    @FindBy(xpath = "//input[@id='login-button']")
    private WebElement btnlogin;

//  validasi login
    @FindBy(xpath = "//div[@class='app_logo']")
    private WebElement mainMenu;

    @FindBy(xpath = "//button[@id='react-burger-menu-btn']")
    private WebElement optionMenu;

    @FindBy(xpath = "//*[@id=\"logout_sidebar_link\"]")
    private WebElement btnlogout;

//    validasi invalid login
    @FindBy(xpath = "//*[@id=\"login_button_container\"]/div/form/div[3]")
    private WebElement invalidLogin ;


    public void loginPage(String username, String password){
        this.username.sendKeys(username);
        this.password.sendKeys(password);
        btnlogin.click();
    }

    public void inputUsername(String username){
        this.username.sendKeys(username);
    }

    public void inputPassword(String password){
        this.password.sendKeys(password);
    }

    public void clickBtnLogin(){
        btnlogin.click();
    }
    public void logOut(){
        optionMenu.click();
        btnlogout.click();
    }

    //    valid login
    public String validLogin(){
        return mainMenu.getText();
    }

    //    username & pass word kosong, password kosong
    public String invalidLogin(){
        return invalidLogin.getText();
    }



}
