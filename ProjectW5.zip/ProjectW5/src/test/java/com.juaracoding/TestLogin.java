package com.juaracoding;


import com.juaracoding.drivers.DriverSingleton;
import com.juaracoding.pages.LoginLogout;
import com.juaracoding.utils.Constant;
import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class TestLogin {

    private static WebDriver driver;
    private static LoginLogout loginLogout;

    @BeforeAll
    public static void setUp(){
        DriverSingleton.getInstance(Constant.CHROME);
        driver = DriverSingleton.getDriver();
        loginLogout = new LoginLogout();
    }

    @AfterAll
    public static void finish(){
        DriverSingleton.delay(5);
        DriverSingleton.closeObjectInstance();
    }

    @Given("User enter url SauceDemo")
    public void user_enter_url_hrm(){
        driver.get(Constant.url);
    }
    @When("User input valid username")
    public void user_input_valid_username(){
        loginLogout.inputUsername("standard_user");
    }

    @And("User input valid password")
    public void user_input_valid_password(){
        loginLogout.inputPassword("secret_sauce");
    }

    @And("User click button login")
    public void user_click_button_login(){
        loginLogout.clickBtnLogin();
    }

    @Then("User get login Validation")
    public void user_get_login_Validation(){
        Assert.assertEquals(loginLogout.validLogin(),"Swag Labs");
        System.out.printf(loginLogout.validLogin());
    }

    //logout
    @Given("User logout")
    public void user_logout(){
        loginLogout.logOut();
    }

    @When("User input invalid username")
    public void user_input_invalid_username(){
        loginLogout.inputUsername("");
    }
    @And("User input invalid password")
    public void user_input_invalid_password(){
        loginLogout.inputPassword("");
    }

//    salah password
    @Then("User get invalid login")
    public void user_get_invalid_login(){
        Assert.assertEquals(loginLogout.invalidLogin(),"Epic sadface: Username is required");
        System.out.printf(loginLogout.invalidLogin());
    }
    @And("User input invalid password2")
    public void user_input_invalid_password2(){
        loginLogout.inputPassword("");
    }

    @Then("User get invalid login2")
    public void user_get_invalid_login2(){
        Assert.assertEquals(loginLogout.invalidLogin(),"Epic sadface: Password is required");
        System.out.printf(loginLogout.invalidLogin());
    }

    @And("User input invalid password3")
    public void user_input_invalid_password3(){
        loginLogout.inputPassword("asdasd");
    }

    @Then("User get invalid login3")
    public void user_get_invalid_login3(){
        Assert.assertEquals(loginLogout.invalidLogin(),
                "Epic sadface: Username and password do not match any user in this service");
        System.out.printf(loginLogout.invalidLogin());
    }



}
