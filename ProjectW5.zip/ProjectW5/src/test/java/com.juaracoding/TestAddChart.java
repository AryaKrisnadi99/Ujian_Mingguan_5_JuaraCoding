package com.juaracoding;

import com.juaracoding.drivers.DriverSingleton;
import com.juaracoding.pages.LoginLogout;
import com.juaracoding.pages.AddProduct;
import com.juaracoding.utils.Constant;
import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;


public class TestAddChart {
    private static WebDriver driver;
    private static LoginLogout loginLogout;

    private static AddProduct addProduct;
    @BeforeAll
    public static void setUp(){
        DriverSingleton.getInstance(Constant.CHROME);
        driver = DriverSingleton.getDriver();
        loginLogout = new LoginLogout();
        addProduct = new AddProduct();
    }

    @AfterAll
    public static void finish(){
        DriverSingleton.delay(5);
        DriverSingleton.closeObjectInstance();
    }


    @Given("User login")
    public  void userLogin(){
        driver.get(Constant.url);
        loginLogout.loginPage("standard_user","secret_sauce");
    }
    @When("User click item to chart")
    public void user_click_item_to_chart(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-10000)");
        addProduct.addItem();
        DriverSingleton.delay(2);

    }

    @And("User click menu shooping cart")
    public void User_click_menu_shooping_cart(){
        addProduct.checkSC();
    }

    @And("User click checkout btn")
    public void checkOutBtn(){
        addProduct.checkOut();
    }

    @And("User input fn ln and zip")
    public void addData(){
        addProduct.inputData("Arya","Krinadi","123");
    }

    @And("User click continue btn")
    public void cntBtn(){
        addProduct.continuebtn();
        DriverSingleton.delay(3);
    }

    @And("User click finish btn")
    public void fnsBtn(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,10000)");
        addProduct.finish();
        DriverSingleton.delay(2);
    }

    @Then("User get message successful")
    public void validCO(){
        Assert.assertEquals(addProduct.validCheckOut(),"Checkout: Complete!");
        DriverSingleton.delay(5);
        addProduct.backHome();
        System.out.printf(addProduct.validCheckOut());
    }

//    invalid check out 1
    @And("User only input zip")
    public void onlyZip(){
        addProduct.inputZip("123");
        DriverSingleton.delay(2);
    }
    @Then("User get error message")
    public void invalidCO(){
        Assert.assertEquals(addProduct.invalidCheckOut(),"Error: First Name is required");
        System.out.printf(addProduct.invalidCheckOut());
    }

//    invalid check out 2

    @Given("User valid input fn")
    public void validFN(){
        addProduct.clearData();
        addProduct.inputFN("Arya");
        DriverSingleton.delay(2);
    }

    @And("User input invalid last name")
    public void invalidLN(){
        addProduct.inputLN("");
    }

    @And("User input invalid zip")
    public void invalidZip(){
        addProduct.inputZip("");
    }

    @Then("User get error message2")
    public void invalidCO2(){
        Assert.assertEquals(addProduct.invalidCheckOut(),"Error: Last Name is required");
        System.out.printf(addProduct.invalidCheckOut());
    }

//    invalid check out 3

    @And("User valid last name")
    public void validLN(){
        addProduct.inputLN("Krinadi");
        DriverSingleton.delay(2);
    }

    @Then("User get error message3")
    public void invalidCO3(){
        Assert.assertEquals(addProduct.invalidCheckOut(),"Error: Postal Code is required");
        System.out.printf(addProduct.invalidCheckOut());
    }
}
